// File: src/components/Homepage.jsx

import React, { useState } from "react";

const Homepage = () => {
  const [showForm1, setShowForm1] = useState(false); // For HTTP1 input form
  const [showForm2, setShowForm2] = useState(false); // For HTTP2 input form
  const [url1, setUrl1] = useState("");
  const [numRequests1, setNumRequests1] = useState(1);
  const [url2, setUrl2] = useState("");
  const [numRequests2, setNumRequests2] = useState(1);

  const [metrics1, setMetrics1] = useState(null);
  const [metrics2, setMetrics2] = useState(null);
  const [loading1, setLoading1] = useState(false);
  const [loading2, setLoading2] = useState(false);
  const [error1, setError1] = useState(null);
  const [error2, setError2] = useState(null);

  // Handle click to show HTTP1 form
  const handleTestClick1 = () => {
    setShowForm1(true);
  };

  // Handle click to show HTTP2 form
  const handleTestClick2 = () => {
    setShowForm2(true);
  };

  // Handle sending request for HTTP1
  const handleSendRequestClick1 = async () => {
    setLoading1(true);
    setError1(null);
    setMetrics1(null);
    try {
      const response = await fetch("http://localhost:8080/api/analyze/http1", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          url: url1,
          numRequests: parseInt(numRequests1, 10),
        }),
      });

      if (!response.ok) {
        throw new Error(`Server error: ${response.statusText}`);
      }

      const data = await response.json();
      setMetrics1(data);
    } catch (error) {
      setError1(error.message);
    } finally {
      setLoading1(false);
    }
  };

  // Handle sending request for HTTP2
  const handleSendRequestClick2 = async () => {
    setLoading2(true);
    setError2(null);
    setMetrics2(null);
    try {
      const response = await fetch("http://localhost:8080/api/analyze/http2", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          url: url2,
          numRequests: parseInt(numRequests2, 10),
        }),
      });

      if (!response.ok) {
        throw new Error(`Server error: ${response.statusText}`);
      }

      const data = await response.json();
      setMetrics2(data);
    } catch (error) {
      setError2(error.message);
    } finally {
      setLoading2(false);
    }
  };

  // Helper function to render metrics
  const renderMetrics = (metrics) => {
    if (!metrics) return null;
    return (
      <div className="mt-4">
        <h4>Performance Metrics:</h4>
        <ul>
          <li>Total Requests: {metrics.totalRequests}</li>
          <li>Successful Requests: {metrics.successfulRequests}</li>
          <li>Failed Requests: {metrics.failedRequests}</li>
          <li>Average Response Time: {metrics.averageResponseTimeMs.toFixed(2)} ms</li>
          <li>Minimum Response Time: {metrics.minResponseTimeMs} ms</li>
          <li>Maximum Response Time: {metrics.maxResponseTimeMs} ms</li>
          <li>
            Status Code Distribution:
            <ul>
              {Object.entries(metrics.statusCodeDistribution).map(([code, count]) => (
                <li key={code}>
                  {code}: {count}
                </li>
              ))}
            </ul>
          </li>
        </ul>
      </div>
    );
  };

  return (
    <div className="container mt-5">
      <div className="row">
        {/* HTTP1 Section */}
        <div className="col-md-6 mb-4">
          {/* Button to reveal HTTP1 input fields */}
          {!showForm1 && (
            <button onClick={handleTestClick1} className="btn btn-primary">
              Test HTTP1
            </button>
          )}

          {/* Conditionally render the input form for HTTP1 */}
          {showForm1 && (
            <div className="card fixed-height">
              <div className="card-body">
                <h2>HTTP1</h2>
                <div className="mb-3">
                  <label htmlFor="urlInput1" className="form-label">
                    URL (HTTP1)
                  </label>
                  <input
                    type="text"
                    id="urlInput1"
                    className="form-control"
                    value={url1}
                    onChange={(e) => setUrl1(e.target.value)}
                    placeholder="Enter URL"
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="requestInput1" className="form-label">
                    Number of Requests (HTTP1)
                  </label>
                  <input
                    type="number"
                    id="requestInput1"
                    className="form-control"
                    value={numRequests1}
                    onChange={(e) => setNumRequests1(e.target.value)}
                    placeholder="Enter number of requests"
                    min="1"
                  />
                </div>
                <button onClick={handleSendRequestClick1} className="btn btn-success" disabled={loading1}>
                  {loading1 ? "Sending..." : "Send HTTP1 Request"}
                </button>
                {error1 && <div className="alert alert-danger mt-3">Error: {error1}</div>}
                {metrics1 && renderMetrics(metrics1)}
              </div>
            </div>
          )}
        </div>

        {/* HTTP2 Section */}
        <div className="col-md-6 mb-4">
          {/* Button to reveal HTTP2 input fields */}
          {!showForm2 && (
            <button onClick={handleTestClick2} className="btn btn-primary">
              Test HTTP2
            </button>
          )}

          {/* Conditionally render the input form for HTTP2 */}
          {showForm2 && (
            <div className="card fixed-height">
              <div className="card-body">
                <h2>HTTP2</h2>
                <div className="mb-3">
                  <label htmlFor="urlInput2" className="form-label">
                    URL (HTTP2)
                  </label>
                  <input
                    type="text"
                    id="urlInput2"
                    className="form-control"
                    value={url2}
                    onChange={(e) => setUrl2(e.target.value)}
                    placeholder="Enter URL"
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="requestInput2" className="form-label">
                    Number of Requests (HTTP2)
                  </label>
                  <input
                    type="number"
                    id="requestInput2"
                    className="form-control"
                    value={numRequests2}
                    onChange={(e) => setNumRequests2(e.target.value)}
                    placeholder="Enter number of requests"
                    min="1"
                  />
                </div>
                <button onClick={handleSendRequestClick2} className="btn btn-success" disabled={loading2}>
                  {loading2 ? "Sending..." : "Send HTTP2 Request"}
                </button>
                {error2 && <div className="alert alert-danger mt-3">Error: {error2}</div>}
                {metrics2 && renderMetrics(metrics2)}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Homepage;
