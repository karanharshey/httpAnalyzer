package com.cp.HttpAnalyzer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HttpAnalyzerApplicationTests {

	@Test
	void contextLoads() {
	}

}
