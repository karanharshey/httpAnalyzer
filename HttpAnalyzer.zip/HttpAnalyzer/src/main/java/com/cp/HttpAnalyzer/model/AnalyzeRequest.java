// File: src/main/java/com/example/HTTPPerformanceAnalyzer/model/AnalyzeRequest.java

package com.cp.HttpAnalyzer.model;

public class AnalyzeRequest {
    private String url;
    private int numRequests;

    // Getters and Setters

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getNumRequests() {
        return numRequests;
    }

    public void setNumRequests(int numRequests) {
        this.numRequests = numRequests;
    }
}
