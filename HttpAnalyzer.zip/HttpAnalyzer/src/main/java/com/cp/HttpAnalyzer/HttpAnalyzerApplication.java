package com.cp.HttpAnalyzer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HttpAnalyzerApplication {

	public static void main(String[] args) {
		SpringApplication.run(HttpAnalyzerApplication.class, args);
	}

}
