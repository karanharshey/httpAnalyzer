// File: src/main/java/com/example/HTTPPerformanceAnalyzer/service/PerformanceMetrics.java

package com.cp.HttpAnalyzer.service;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class PerformanceMetrics {
    private final List<Long> responseTimes = Collections.synchronizedList(new ArrayList<>());
    private final List<Integer> statusCodes = Collections.synchronizedList(new ArrayList<>());
    private final AtomicInteger errorCount = new AtomicInteger(0);

    public void addResponseTime(long timeNano) {
        responseTimes.add(timeNano);
    }

    public void addStatusCode(int code) {
        statusCodes.add(code);
    }

    public void incrementErrors() {
        errorCount.incrementAndGet();
    }

    // Getters for JSON serialization

    public int getTotalRequests() {
        return responseTimes.size() + errorCount.get();
    }

    public int getSuccessfulRequests() {
        return responseTimes.size();
    }

    public int getFailedRequests() {
        return errorCount.get();
    }

    public double getAverageResponseTimeMs() {
        return responseTimes.stream()
                .mapToLong(Long::longValue)
                .average()
                .orElse(0.0) / 1_000_000.0;
    }

    public long getMinResponseTimeMs() {
        return responseTimes.stream()
                .mapToLong(Long::longValue)
                .min()
                .orElse(0L) / 1_000_000;
    }

    public long getMaxResponseTimeMs() {
        return responseTimes.stream()
                .mapToLong(Long::longValue)
                .max()
                .orElse(0L) / 1_000_000;
    }

    public Map<Integer, Long> getStatusCodeDistribution() {
        Map<Integer, Long> distribution = new TreeMap<>();
        for (Integer code : statusCodes) {
            distribution.put(code, distribution.getOrDefault(code, 0L) + 1);
        }
        return distribution;
    }
}
