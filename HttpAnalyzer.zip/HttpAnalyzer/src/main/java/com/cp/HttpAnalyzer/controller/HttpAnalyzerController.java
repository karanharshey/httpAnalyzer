// File: src/main/java/com/example/HTTPPerformanceAnalyzer/controller/HTTPAnalyzerController.java

package com.cp.HttpAnalyzer.controller;

import com.cp.HttpAnalyzer.model.AnalyzeRequest;
import com.cp.HttpAnalyzer.service.Http1Analyzer;
import com.cp.HttpAnalyzer.service.Http2Analyzer;
import com.cp.HttpAnalyzer.service.PerformanceMetrics;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

// Enable CORS for all origins or specify allowed origins
@CrossOrigin(origins = "http://localhost:5173") // Adjust the port if your React app runs on a different port
@RestController
@RequestMapping("/api/analyze")
public class HttpAnalyzerController {

    @Autowired
    private Http1Analyzer http1Analyzer;

    @Autowired
    private Http2Analyzer http2Analyzer;

    @PostMapping("/http1")
    public ResponseEntity<PerformanceMetrics> analyzeHTTP1(@RequestBody AnalyzeRequest request) {
        PerformanceMetrics metrics = http1Analyzer.analyze(request.getUrl(), request.getNumRequests());
        return ResponseEntity.ok(metrics);
    }

    @PostMapping("/http2")
    public ResponseEntity<PerformanceMetrics> analyzeHTTP2(@RequestBody AnalyzeRequest request) {
        PerformanceMetrics metrics = http2Analyzer.analyze(request.getUrl(), request.getNumRequests());
        return ResponseEntity.ok(metrics);
    }
}
