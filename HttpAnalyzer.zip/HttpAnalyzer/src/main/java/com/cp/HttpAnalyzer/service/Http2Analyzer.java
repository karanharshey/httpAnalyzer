package com.cp.HttpAnalyzer.service;

import com.cp.HttpAnalyzer.HttpProtocolAnalyzer;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Service
public class Http2Analyzer implements HttpProtocolAnalyzer {

    private final int threadPoolSize = 4; // Smaller pool size due to multiplexing

    @Override
    public PerformanceMetrics analyze(String url, int numRequests) {
        ExecutorService executor = Executors.newFixedThreadPool(threadPoolSize);
        PerformanceMetrics metrics = new PerformanceMetrics();

        HttpClient client = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_2)
                .build();

        for (int i = 0; i < numRequests; i++) {
            executor.submit(() -> {
                try {
                    HttpRequest request = HttpRequest.newBuilder()
                            .uri(URI.create(url))
                            .GET()
                            .build();

                    long startTime = System.nanoTime();
                    HttpResponse<Void> response = client.send(request, HttpResponse.BodyHandlers.discarding());
                    long endTime = System.nanoTime();

                    metrics.addResponseTime(endTime - startTime);
                    metrics.addStatusCode(response.statusCode());
                } catch (Exception e) {
                    metrics.incrementErrors();
                }
            });
        }

        executor.shutdown();
        try {
            boolean finished = executor.awaitTermination(30, java.util.concurrent.TimeUnit.MINUTES);
            if (!finished) {
                System.err.println("HTTP/2 Analyzer timed out.");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        return metrics;
    }
}
