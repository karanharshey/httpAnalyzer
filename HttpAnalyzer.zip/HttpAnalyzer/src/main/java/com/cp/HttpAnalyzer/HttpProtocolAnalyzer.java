// File: src/main/java/com/example/HTTPPerformanceAnalyzer/HTTPProtocolAnalyzer.java

package com.cp.HttpAnalyzer;

import com.cp.HttpAnalyzer.service.PerformanceMetrics;

public interface HttpProtocolAnalyzer {
    PerformanceMetrics analyze(String url, int numRequests);
}
